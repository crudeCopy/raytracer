/* chang
 * implements a scene type, which holds info from the input file */

#ifndef SCENE_H
#define SCENE_H

#include "point.h"
#include "vector.h"
#include "ray.h"
#include "object.h"
#include "color.h"
#include "light.h"
#include "depth_cue.h"

/* constants for maximum values of objects and colors */
const static unsigned MAX_OBJECTS = 10,
               MAX_MTL_COLORS = 10,
               MAX_LIGHTS = 5;

/* scene type; one image will have one scene_t associated
 * three groups of members:
 *    known before input -> d
 *
 *    from input file -> view_orig, view_dir, up_dir, fov_h, objects, object_count, 
 *                       img_width, img_height, projection_type, bkg_color, mtl_colors
 *
 *    calculated -> win_width, win_height, aspect, fov_v, ul, ur, ll, lr, dw, dh, u, v, n
*/
typedef struct {
    point_t view_orig,      /* center of projection */
            ul, ur, ll, lr; /* corners of viewing window */

    vector_t view_dir, /* viewing direction */
             up_dir,   /* global "up" direction */
             u, v,     /* vecs orthogonal to viewing window plane */
             n,        /* vec normal to viewing window plane; maybe unnecessary? just -1*view_dir */
             dw, dh,   /* translations from one window location to next */
             ret;      /* translations from end of window row to beginning */

    float win_width,  /* width of the viewing window */
          win_height, /* height of the viewing window*/
          aspect,     /* aspect ratio */
          fov_h,      /* horizontal field of view; to be supplied */
          d,          /* distance along view_dir between view_orig and center point of viewing window; arbitrary */
          soft_shade_light_delta; /* how far from the light origin a soft-shade ray can be at most */

    object_t *objects; /* set of given objects to include, holds up to 10 */

    unsigned object_count,    /* holds how many items are initialized in objects */
             light_count,     /* holds how many light sources are initialized in lights */
             img_width,       /* width of output in pixels */
             img_height,      /* height of output in pixels */ 
             projection_type, /* type of projection; 0 = perspective, 1 = parallel; 0 by default */
             soft_shading,    /* whether soft shading is enabled or not; 0 = no, 1 = yes; 0 by default */
             soft_shade_ray_count; /* how many rays to use in soft shading alg */

    color_t bkg_color;       /* background color */
    mtl_color_t *mtl_colors; /* material color */

    light_t *lights;   /* list of light sources in the scene */

    depth_cue_t depth_cue; /* holds user-given values about depth cue */
    int has_depth_cue;     /* makes it known whether there is a depth cue for the scene (1 = true, 0 = false) */
} scene_t;

/* read scene info from input file located at file_path into scene 
 * returns 1 if success, 0 if fail */
int scene_from_file (scene_t *scene, char *file_path);

/* destroy scene object */
void scene_destroy (scene_t *scene);

/* trace ray, similar to specification 
 * trace_type: 0.0 means initial call, >0 means call for shadow check, represents distance from surface to light
 * src_obj: index of object checking for shadows in array, allows skipping itself (value doesn't matter if trace_type == 0 */
color_t trace_ray (ray_t *ray, scene_t *scene, float trace_type, int src_obj);

/* shade ray, similar to spec
 * src_obj: index of object being shaded */
color_t shade_ray (scene_t *scene,/*TODO object_t *obj,*/ point_t *surface, int src_obj);

#endif /* SCENE_H */
