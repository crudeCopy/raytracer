/* chang
 * implements the depth cue alpha function
 */

#include "depth_cue.h"

/* get alpha_dc of the given depth cue at the given float distance */
float depth_cue_alpha (depth_cue_t *cue, float d_obj) {
    float result;
    
    if (d_obj <= cue->d_near) return cue->alpha_max;
    else if (d_obj > cue->d_far) return cue->alpha_min;

    result = cue->alpha_min + (cue->alpha_max - cue->alpha_min) * ((cue->d_far - d_obj) / (cue->d_far - cue->d_near));

    return result;
}
