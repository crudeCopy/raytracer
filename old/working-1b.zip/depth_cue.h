/* chang
 * defines the depth cue object of a 3d scene */

#ifndef DEPTH_CUE_H
#define DEPTH_CUE_H

#include "color.h"

/* depth_cue_t:
 *   intended as a member of a scene_t, will hold all info related to depth cueing.
 */
typedef struct {
    color_t color; /* depth cue color, the color the scene fades into */

    float alpha_max, alpha_min, /* minimum and maximum values of the alpha function */
          d_far, d_near;        /* user-defined far and near distances */
} depth_cue_t;

/* get alpha_dc of the given depth cue at the given float distance */
float depth_cue_alpha (depth_cue_t *cue, float d_obj);

#endif /* DEPTH_CUE_H */
