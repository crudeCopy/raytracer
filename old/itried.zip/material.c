/* 
 * chang
 *
 * Home of the "object," "object_list," "color," "mtl_color," and "mtl_color_list" typedefs' functions.
 * Formerly the contents of object.c and color.c, this was redundant.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "material.h"

/*================================== COLORS =====================================*/

/* converts from normalized storage to three int pointers of value between 0 and 255 */
void color_to_ints (color_t *color, int *r, int *g, int *b) {
    *r = (int) (color->r * 255);
    *g = (int) (color->g * 255);
    *b = (int) (color->b * 255);
}

/* takes color_t array and creates {name}.ppm
 * returns 1 if success, 0 if fail */
int write_colors_to_ppm (char *name, color_t *pixels, unsigned w, unsigned h) {
    FILE *file;
    int r, g, b;
    unsigned i, row = 0,
             total_px = w * h;

    /* strip suffix from filename */
    name = strtok (name, ".");

    /* add .ppm */
    strcat (name, ".ppm");

    /* open/create file */
    file = fopen (name, "w");

    if (file == NULL) { /* this should NOT happen, but just in case */
        fprintf (stderr, "write_colors_to_ppm () unable to open file %s for some reason, write fail", name);
        return 0;
    }

    /* do header */
    fprintf (file, "# chang\nP3\n%d %d\n255\n", w, h);

    /* do body */
    for (i = 0; i < total_px; i++) {
        /* convert current pixel color_t to ints */
        color_to_ints (&(pixels[i]), &r, &g, &b);

        /* print to file */
        fprintf (file, "%d %d %d ", r, g, b);
        row++;

        /* check if row too long */
        if (row >= 5) {
            fprintf (file, "\n");
            row = 0;
        }
    }

    fclose (file);

    return 1;
}



/* initializes dest with size 0 and a NULL head */
void mtl_color_list_init (mtl_color_list_t *dest) {
    dest->size = 0;
    dest->head = NULL;
}    

/* adds new mtl_color to dest, 1 if success, 0 if fail */
int mtl_color_list_prepend (mtl_color_list_t *dest, mtl_color_t *new_color) {
    /* handle case of empty list */
    if (dest->head == NULL) {
        dest->head = new_color;
        new_color->next = NULL;
        dest->size = 1;
        return 0;
    }

    /* make the new color the head of list */
    new_color->next = dest->head;
    dest->head = new_color;

    dest->size++;
    return 0;
}



/*================================== OBJECTS ====================================*/

/* initializes an object_t of type t with color input_color and
 * parameters from input_args; stores to dest; 1 = success, 0 = fail */
int object_init (object_t *dest, unsigned t, mtl_color_t *input_color, char *input_args) {
    unsigned i;
    char *arg_tokenized;


    /* set type and color */
    dest->type = t;
    dest->color = *input_color; /* TODO*/
    dest->next = NULL;


    /* check object type is valid TODO: update */
    switch (t) {
        case 0:
            dest->argcount = 4;
            break;
        case 1:
            dest->argcount = 8;
            break;
        default:
            fprintf (stderr, "object_init () was passed an unknown object type %d, init fail\n", t);
            return 0;
    }


    /* allocate right amount of space for args */
    dest->args = (float *) malloc(dest->argcount * sizeof(float));


    /* perform surgery on the string */
    arg_tokenized = strtok (input_args, " ");


    /* read in the right amount of arguments from file */
    i = 0;
    while (arg_tokenized != NULL && i < dest->argcount) {
        dest->args [i] = atof (arg_tokenized);
        i++;
        arg_tokenized = strtok (NULL, " ");
    }

    return 0;
}

/* only slightly better than dest = src, should make dest a copy of src 
void object_copy_init (object_t *dest, object_t *src) {

}*/


/* init object_list_t with size of 0 and NULL head */
void object_list_init (object_list_t *dest) {
    dest->size = 0;
    dest->head = NULL;
}

/* add object to object_list_t dest; 1 = success, 0 = fail */
int object_list_append (object_list_t *dest, unsigned t, mtl_color_t *input_color, char *input_args) {
    object_t *current_obj;

    /* handle empty list */ /* TODO: consider handling out-of-range object entry errors here */
    if (dest->head == NULL) {
        object_init (dest->head, t, input_color, input_args);
        dest->size = 1;
        return 0;
    }

    /* otherwise put at end of current list */
    current_obj = dest->head;

    while (current_obj->next != NULL)
        current_obj = current_obj->next;

    object_init (current_obj->next, t, input_color, input_args);

   /* current_obj->next = new_obj;
    new_obj->next = NULL;*/
    dest->size++;
    return 0;
}

/* destroy object list */
void object_list_destroy (object_list_t *list) {
    object_t *current_obj = list->head;
    list->head = NULL;
    list->size = 0;

    /* free all arguments arrays */
    while (current_obj->next != NULL) {
        free (current_obj->args);
        current_obj = current_obj->next;
    }
    free (current_obj->args);
}
