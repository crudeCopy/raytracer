/* chang
 * expands on the scene type, adding a method for reading 
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>

#include "scene.h"


/* read scene info from input file located at file_path into scene */
int scene_from_file (scene_t *scene, char *file_path) {
    FILE *file;
    /* variables to hold scanned values */
    char key[20], args[128];
    float f1, f2, f3,
          length;
    unsigned i1, i2, i3,
             i4, i5, i6,
             i7, i8, i9,
             current_mtl_color = 0;
    light_t *current_light;

    /* variables to check for important variable initialization TODO */
    unsigned has_eye = 0,
             has_viewdir = 0,
             has_updir = 0,
             has_hfov = 0,
             has_imsize = 0,
             has_bkgcolor = 0,
             has_mtlcolors = 0,  /* these two will be true (=1) if any    */
             has_projection = 0,
             got_texture_last = 0;

    /* automatically no soft shading */
    scene->soft_shading = 0;

    /* variables for math after reading */
    point_t win_center,
            new_end;
    vector_t view_orig_to_win,
             half_width_u,
             half_height_v;

    /* set counts to 0 */
    scene->object_count = 0;
    scene->light_count = 0;
    scene->vert_count = 0;
    scene->tri_count = 0;
    scene->norm_count = 0;
    scene->texture_count = 0;
    scene->img_coord_count = 0;

    /* initialize objects and mtl_colors */
    scene->objects = malloc (MAX_OBJECTS * sizeof (object_t));
    scene->mtl_colors = malloc (MAX_MTL_COLORS * sizeof (mtl_color_t));
    scene->lights = malloc (MAX_LIGHTS * sizeof (light_t));
    scene->verts = malloc (MAX_VERTS * sizeof (point_t));
    scene->tris = malloc (MAX_TRIS * sizeof (triangle_t));
    scene->norms = malloc (MAX_VERTS * sizeof (vector_t));
    scene->textures = malloc (MAX_TEXTURES * sizeof (image_t));
    scene->img_coords = malloc (MAX_VERTS * sizeof (img_coord_t));

    /* no depth cue by default */
    scene->has_depth_cue = 0;

    /* open file, test if exists/is open */
    file = fopen (file_path, "r");

    if (file == NULL) {
        fprintf (stderr, "scene_from_file () was passed a path to a file %s that either doesn't exist or cannot be opened, read scene fail\n", file_path);
        return 0;
    }

    /* read through keywords until EOF */    
    while (fscanf (file, "%s ", key) != EOF) {
        if (strcmp (key, "eye") == 0) { /* eye */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            scene->view_orig = (point_t) {f1, f2, f3};

            has_eye = 1;
        }
        else if (strcmp (key, "viewdir") == 0) { /* viewdir */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            scene->view_dir = (vector_t) {f1, f2, f3};
            scene->n = (vector_t) {-f1, -f2, -f3}; /* n is defined as -view_dir */

            /* normalize */
            has_viewdir = vec_normalize (&(scene->view_dir)); /* will be 0 if vector is {0, 0, 0}, 1 otherwise */
            vec_normalize (&(scene->n));
        }
        else if (strcmp (key, "updir") == 0) { /* updir */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            scene->up_dir = (vector_t) {f1, f2, f3};

            /* normalize */
            has_updir = vec_normalize (&(scene->up_dir));
        }
        else if (strcmp (key, "hfov") == 0) { /* hfov */
            fscanf (file, "%f", &f1);
            scene->fov_h = f1;

            has_hfov = 1;
        }
        else if (strcmp (key, "imsize") == 0) { /* imsize */
            fscanf (file, "%d %d", &i1, &i2);
            scene->img_width = i1;
            scene->img_height = i2;

            has_imsize = 1;
        }
        else if (strcmp (key, "bkgcolor") == 0) { /* bkgcolor */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            scene->bkg_color = (color_t) {f1, f2, f3};

            has_bkgcolor = 1;
        }
        else if (strcmp (key, "mtlcolor") == 0) { /* mtlcolor */
            /* check if max number of colors are already loaded */
            if (current_mtl_color >= MAX_MTL_COLORS - 1) {
                fprintf (stderr, "too many colors loaded, read fail\n");
                return 0;
            }
            
            /* get diffuse color */
            fscanf (file, "%f %f %f ", &f1, &f2, &f3);
            scene->mtl_colors[current_mtl_color].od = (color_t) {f1, f2, f3};

            /* get specular color */
            fscanf (file, "%f %f %f ", &f1, &f2, &f3);
            scene->mtl_colors[current_mtl_color].os = (color_t) {f1, f2, f3};

            /* get constants */
            fscanf (file, "%f %f %f ", &f1, &f2, &f3);
            scene->mtl_colors[current_mtl_color].ka = f1;
            scene->mtl_colors[current_mtl_color].kd = f2;
            scene->mtl_colors[current_mtl_color].ks = f3;

            /* get falloff control */
            fscanf (file, "%f", &f1);
            scene->mtl_colors[current_mtl_color].n = f1;

            current_mtl_color++;

            got_texture_last = 0;
            has_mtlcolors = 1;
        }
        else if (strcmp (key, "sphere") == 0) { /* object */
            /* check if max number of objects are already loaded */
            if (scene->object_count >= MAX_OBJECTS) {
                fprintf (stderr, "too many objects loaded, read fail\n");
                return 0;
            }

            /* check if there is a color for this thing */
            if (has_mtlcolors != 1) {
                fprintf (stderr, "scene_from_file () read an object before a mtlcolor, read fail\n");
                return 0;
            }

            fgets (args, sizeof(args), file); /* read whole rest of line */

            object_init (&(scene->objects [scene->object_count]), 0, &(scene->mtl_colors [current_mtl_color - 1]), args); /* awfully long */

            /* if texture was gotten more recently than mtlcolor, set texture. */
            if (got_texture_last == 1)
                scene->objects[scene->object_count].texture = &(scene->textures[scene->texture_count - 1]);

            scene->object_count++;
        }
        else if (strcmp (key, "projection") == 0) { /* projection */
            fscanf (file, "%s", args);
            if (strcmp (args, "perspective") == 0) {
                scene->projection_type = 0;
            } else if (strcmp (args, "parallel") == 0) {
                scene->projection_type = 1;
            } else {
                fprintf (stderr, "scene_from_file () read keyword projection but found undefined projection type afterwards, read fail\n");
                return 0;
            }
            has_projection = 1;
        }
        else if (strcmp (key, "light") == 0 || strcmp (key, "attlight") == 0) { /* light */
            /* check if going over max number of lights */
            if (scene->light_count >= MAX_LIGHTS) {
                fprintf (stderr, "too many light sources loaded, read fail\n");
                return 0;
            }

            current_light = &(scene->lights[scene->light_count]);
            
            /* get pos/vec */
            fscanf (file, "%f %f %f ", &f1, &f2, &f3);
            current_light->x = f1;
            current_light->y = f2;
            current_light->z = f3;

            /* get light type */
            fscanf (file, "%d ", &i1);
            if (i1 != 0 && i1 != 1) {
                fprintf (stderr, "unknown light source type %d read, read fail\n", i1);
                return 0;
            }
            current_light->type = i1;

            /* if vec, normalize */
            if (i1 == 0) {
                length = sqrt (f1 * f1 + f2 * f2 + f3 * f3);
                
                current_light->x /= length;
                current_light->y /= length;
                current_light->z /= length;
            }

            /* get light color */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            current_light->color = (color_t) {f1, f2, f3};

            /* account for attlight */
            if (strcmp (key, "attlight") == 0) {
                current_light->type += 2;

                /* get attenuation constants */
                fscanf (file, " %f %f %f", &f1, &f2, &f3);
                current_light->c1 = f1;
                current_light->c2 = f2;
                current_light->c3 = f3;
            }

            /* increment light count by 1 */
            scene->light_count++;
        }
        else if (strcmp (key, "depthcueing") == 0) { /* depth cue */
            /* get cue color */
            fscanf (file, "%f %f %f ", &f1, &f2, &f3);
            scene->depth_cue.color = (color_t) {f1, f2, f3};

            /* get cue alpha max/min */
            fscanf (file, "%f %f ", &f1, &f2);
            scene->depth_cue.alpha_max = f1;
            scene->depth_cue.alpha_min = f2;

            /* get cue distance far/near */
            fscanf (file, "%f %f", &f1, &f2);
            scene->depth_cue.d_far = f1;
            scene->depth_cue.d_near = f2;

            /* update the scene to show it has a depth cue */
            scene->has_depth_cue = 1;
        }
        else if (strcmp (key, "softshading") == 0) { /* soft shading enable */
            /* get light delta and ray count */
            fscanf (file, "%f %d", &f1, &i1);
            scene->soft_shading = 1;
            scene->soft_shade_light_delta = f1;
            scene->soft_shade_ray_count = i1;
        }
        else if (strcmp (key, "#") == 0) { /* comment */
            fgets (args, sizeof (args), file); /* basically seek to end of line */
        }
        else if (strcmp (key, "v") == 0) { /* vertex */
            /* check if going over vertex limit */
            if (scene->vert_count >= MAX_VERTS) {
                fprintf (stderr, "too many vertices, read fail\n");
                return 0;
            }

            /* get point */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            scene->verts[scene->vert_count] = (point_t) {f1, f2, f3};

            /* increment count */
            scene->vert_count++;
        }
        else if (strcmp (key, "vn") == 0) { /* vertex normal */
            /* check if going over vertex (normal) limit */
            if (scene->norm_count >= MAX_VERTS) {
                fprintf (stderr, "too many vertex normals, read fail\n");
                return 0;
            }

            /* get normal vector */
            fscanf (file, "%f %f %f", &f1, &f2, &f3);
            scene->norms[scene->norm_count] = (vector_t) {f1, f2, f3};

            /* increment count */
            scene->norm_count++;
        }
        else if (strcmp (key, "f") == 0) { /* triangle */ /*TODO: UPDATE FOR NEW FORMATS */
            /* check if max tris */
            if (scene->tri_count >= MAX_TRIS) {
                fprintf (stderr, "too many triangles, read fail\n");
                return 0;
            }

            /* check if there is a color */
            if (has_mtlcolors != 1) {
                fprintf (stderr, "scene_from_file () read a face before a mtlcolor, read fail\n");
                return 0;
            }

            /* get vert index/texture/vector norm */
            fgets (args, sizeof (args), file);
            
            if (sscanf (args, "%d/%d/%d %d/%d/%d %d/%d/%d", &i1, &i2, &i3, &i4, &i5, &i6, &i7, &i8, &i9) == 9) { /* param supreme; all 3 */
                /* check if scene has textures */
                if (scene->texture_count <= 0) {
                    fprintf (stderr, "tried assigning a triangle with texture coords before passing a texture, read fail\n");
                    return 0;
                }

                /* assign each pointer, checking if all within range */
                if ((i1 <= 0 || i1 > scene->vert_count) ||
                    (i4 <= 0 || i4 > scene->vert_count) ||
                    (i7 <= 0 || i7 > scene->vert_count)) {
                    fprintf (stderr, "vertex index out of range, read fail\n");
                    return 0;
                }
            
                /* check if all textures within range */
                if ((i2 <= 0 || i2 > scene->img_coord_count) ||
                    (i5 <= 0 || i5 > scene->img_coord_count) ||
                    (i8 <= 0 || i8 > scene->img_coord_count)) {
                    fprintf (stderr, "texture coordinate index out of range, read fail\n");
                    return 0;
                }

                /* check if all normal vectors within range */
                if ((i3 <= 0 || i3 > scene->norm_count) ||
                    (i6 <= 0 || i6 > scene->norm_count) ||
                    (i9 <= 0 || i9 > scene->norm_count)) {
                    fprintf (stderr, "vertex normal index out of range, read fail\n");
                    return 0;
                }

                /* init the triangle based on these three points */
                tri_init (&(scene->tris[scene->tri_count]), &(scene->verts[i1 - 1]),
                          &(scene->verts[i4 - 1]), &(scene->verts[i7 - 1]), &(scene->mtl_colors [current_mtl_color - 1]));

                /* give pointer to recent texture */
                scene->tris[scene->tri_count].texture = &(scene->textures[scene->texture_count - 1]);

                /* give pointers to requested texture coords */
                scene->tris[scene->tri_count].coords[0] = &(scene->img_coords[i2 - 1]);
                scene->tris[scene->tri_count].coords[1] = &(scene->img_coords[i5 - 1]);
                scene->tris[scene->tri_count].coords[2] = &(scene->img_coords[i8 - 1]);

                /* add vertex norms to the triangle */
                tri_add_norms (&(scene->tris[scene->tri_count]), &(scene->norms[i3 - 1]),
                               &(scene->norms[i6 - 1]), &(scene->norms[i9 - 1]));
            }
            else if (sscanf (args, "%d//%d %d//%d %d//%d", &i1, &i2, &i3, &i4, &i5, &i6) == 6) { /* verts and norms */
                /* assign each pointer, checking if all within range */
                if ((i1 <= 0 || i1 > scene->vert_count) ||
                    (i3 <= 0 || i3 > scene->vert_count) ||
                    (i5 <= 0 || i5 > scene->vert_count)) {
                    fprintf (stderr, "vertex index out of range, read fail\n");
                    return 0;
                }
                if ((i2 <= 0 || i2 > scene->norm_count) ||
                    (i4 <= 0 || i4 > scene->norm_count) ||
                    (i6 <= 0 || i6 > scene->norm_count)) {
                    fprintf (stderr, "vertex normal index out of range, read fail\n");
                    return 0;
                }

                /* init the triangle based on these three points */
                tri_init (&(scene->tris[scene->tri_count]), &(scene->verts[i1 - 1]),
                          &(scene->verts[i3 - 1]), &(scene->verts[i5 - 1]), &(scene->mtl_colors [current_mtl_color - 1]));

                /* add vertex norms to the triangle */
                tri_add_norms (&(scene->tris[scene->tri_count]), &(scene->norms[i2 - 1]),
                               &(scene->norms[i4 - 1]), &(scene->norms[i6 - 1]));
            }
            else if (sscanf (args, "%d/%d %d/%d %d/%d", &i1, &i2, &i3, &i4, &i5, &i6) == 6) { /* verts and textures */
                /* check if scene has textures */
                if (scene->texture_count <= 0) {
                    fprintf (stderr, "tried assigning a triangle with texture coords before passing a texture, read fail\n");
                    return 0;
                }

                /* check if all vertices within range */
                if ((i1 <= 0 || i1 > scene->vert_count) ||
                    (i3 <= 0 || i3 > scene->vert_count) ||
                    (i5 <= 0 || i5 > scene->vert_count)) {
                    fprintf (stderr, "vertex index out of range, read fail\n");
                    return 0;
                }

                /* check if all textures within range */
                if ((i2 <= 0 || i2 > scene->img_coord_count) ||
                    (i4 <= 0 || i4 > scene->img_coord_count) ||
                    (i6 <= 0 || i6 > scene->img_coord_count)) {
                    fprintf (stderr, "texture coordinate index out of range, read fail\n");
                    return 0;
                }

                /* init the triangle based on these three points */
                tri_init (&(scene->tris[scene->tri_count]), &(scene->verts[i1 - 1]),
                          &(scene->verts[i3 - 1]), &(scene->verts[i5 - 1]), &(scene->mtl_colors [current_mtl_color - 1]));

                /* give pointer to recent texture */
                scene->tris[scene->tri_count].texture = &(scene->textures[scene->texture_count - 1]);

                /* give pointers to texture coords requested */
                scene->tris[scene->tri_count].coords[0] = &(scene->img_coords[i2 - 1]);
                scene->tris[scene->tri_count].coords[1] = &(scene->img_coords[i4 - 1]);
                scene->tris[scene->tri_count].coords[2] = &(scene->img_coords[i6 - 1]);
            }
            else if (sscanf (args, "%d %d %d", &i1, &i2, &i3) == 3) { /* verts only */
                /* assign each pointer, checking if all within range */
                if ((i1 <= 0 || i1 > scene->vert_count) ||
                    (i2 <= 0 || i2 > scene->vert_count) ||
                    (i3 <= 0 || i3 > scene->vert_count)) {
                    fprintf (stderr, "vertex index out of range, read fail\n");
                    return 0;
                }

                /* init the triangle based on these three points */
                tri_init (&(scene->tris[scene->tri_count]), &(scene->verts[i1 - 1]),
                          &(scene->verts[i2 - 1]), &(scene->verts[i3 - 1]), &(scene->mtl_colors [current_mtl_color - 1]));
            }
            else { /* error */
                fprintf (stderr, "scene_from_file () found strange arcane face format, read fail\n");
                return 0;
            }

            /* increment count */
            scene->tri_count++;
        }
        else if (strcmp (key, "texture") == 0) { /* texture file */
            /* get filename */
            fscanf (file, "%s", args);

            if (image_init (&(scene->textures[scene->texture_count]), args) != 1) { /* read error */
                fprintf (stderr, "scene_from_file () had a tough time getting the texture at %s, read fail\n", args);
                return 0;
            }

            got_texture_last = 1;
            scene->texture_count++;
        }
        else if (strcmp (key, "vt") == 0) { /* texture image coords */
            /* get coords */
            fscanf (file, "%f %f", &f1, &f2);

            /* check if not in range */
            if ((f1 < 0 || f1 > 1) || (f2 < 0 || f2 > 1)) {
                fprintf (stderr, "scene_from_file () found an image coordinate outside of range [0, 1], read fail\n");
                return 0;
            }

            /* update latest image coord */
            scene->img_coords[scene->img_coord_count] = (img_coord_t) {f1, f2};

            /* increment image coord count */
            scene->img_coord_count++;
        }
        else {
            fprintf (stderr, "scene_from_file () read unknown key '%s', read fail\n", key);
            return 0;
        }
    }

    /* close file */
    fclose (file);


    /* now that input has been gotten, check if all necessary values are present */
    if ((has_eye + has_viewdir + has_hfov + has_imsize) != 4) {
        fprintf (stderr, "scene_from_file () read from an input file with one or more missing essential value\n");
        return 0;
    }


    /* TODO TODO TODO UPDATE has_* variables */


    /* setup default values if necessary */
    if (has_updir == 0) scene->up_dir = (vector_t) {0.0, 1.0, 0.0};      /* updir automatically "straight-on" or "no-roll" */
    if (has_bkgcolor == 0) scene->bkg_color = (color_t) {0.0, 0.0, 0.0}; /* bkgcolor automatically black */
    if (has_projection == 0) scene->projection_type = 0;                 /* projection automatically perspective */    

    
    /* extrapolate unknowns from input known values */

    scene->d = 1.0;
    scene->aspect = ((float) scene->img_width) / ((float) scene->img_height);
    
    scene->win_width = 2.0 * scene->d * tan (0.5 * (scene->fov_h * (M_PI/180.0)));         /* win_width */
    scene->win_height = scene->win_width / scene->aspect; /* win_height */

    /* VECTOR TIME */

    vec_cross (&(scene->u), &(scene->view_dir), &(scene->up_dir));
    vec_normalize (&(scene->u)); /* u, normalized */

    vec_cross (&(scene->v), &(scene->u), &(scene->view_dir)); /* v, cross of two orthog. unit vecs, already normal */


    /* CORNER TIME */

    view_orig_to_win = scene->view_dir;
    vec_scale (&view_orig_to_win, scene->d); 
    point_plus_vec (&win_center, &(scene->view_orig), &view_orig_to_win); /* win_center = view_origin + d*view_dir */
  
    half_width_u = scene->u;
    vec_scale (&half_width_u, -(scene->win_width / 2.0)); /* -(w/2)*u */
    half_height_v = scene->v;
    vec_scale (&half_height_v, scene->win_height / 2.0);  /* +(h/2)*v */
    
    point_plus_vec (&(scene->ul), &win_center, &half_width_u);
    point_plus_vec (&(scene->ul), &(scene->ul), &half_height_v); /* ul */

    vec_scale (&half_width_u, -1.0); /* +(w/2)*u */
    point_plus_vec (&(scene->ur), &win_center, &half_width_u);
    point_plus_vec (&(scene->ur), &(scene->ur), &half_height_v); /* ur */

    vec_scale (&half_width_u, -1.0); /* -(w/2)*u */
    vec_scale (&half_height_v, -1.0); /* -(h/2)*v */
    point_plus_vec (&(scene->ll), &win_center, &half_width_u);
    point_plus_vec (&(scene->ll), &(scene->ll), &half_height_v); /* ll */

    vec_scale (&half_width_u, -1.0); /* +(w/2)*u */
    point_plus_vec (&(scene->lr), &win_center, &half_width_u);
    point_plus_vec (&(scene->lr), &(scene->lr), &half_height_v); /* lr */


    /* DELTAS */

    vec_from_to (&(scene->dw), &(scene->ul), &(scene->ur));
    vec_from_to (&(scene->dh), &(scene->ul), &(scene->ll));
    vec_scale (&(scene->dw), 1.0 / ((float) scene->img_width - 1.0));
    vec_scale (&(scene->dh), 1.0 / ((float) scene->img_height - 1.0));
    point_plus_vec (&new_end, &(scene->ur), &(scene->dw));
    vec_from_to (&(scene->ret), &new_end, &(scene->ul));


    return 1;
}

/* destructor for initialized scenes */
void scene_destroy (scene_t *scene) {
    int i;

    /* destroy each object */
    for (i = 0; i < scene->object_count; i++) {
        object_destroy (&(scene->objects [i]));
    }

    /* destroy objects, mtl_colors, and lights */
    free (scene->objects);
    free (scene->mtl_colors);
    free (scene->lights);
    free (scene->verts);
    free (scene->tris);
    free (scene->norms);

    /* free individual textures */
    for (i = 0; i < scene->texture_count; i++) {
        image_destroy (&(scene->textures[i]));
    }
    free (scene->textures);

    free (scene->img_coords);
}

/* trace ray, similar to specification */
color_t trace_ray (ray_t *ray, scene_t *scene, float trace_type, int src_obj, int src_tri) {
    unsigned i;
    float b, c,
          t_add, t_sub, /* variables used in calculation of ray intersection */
          discriminant,
          numerator, denominator,
          closest_distance = FLT_MAX; /* arbitrarily large to start with */
    point_t point_add, point_sub,
            surface_point;
    object_t curr_obj;
    color_t result_color = scene->bkg_color; /* bkg by default */

    triangle_t *curr_tri;
    vector_t e_p;
    float d_00, d_01, d_11, d_0p, d_1p,
          determinant;
    point_t barycentrics; /* for barycentrics */


    /* check for collision with each object */
    for (i = 0; i < scene->object_count; i++) {
        /* if an object is checking for shadow ray intersects, skips itself */
        if (trace_type > 0.0f && src_obj == i) continue;

        curr_obj = scene->objects[i];

        /* calculate components of intersection model */

        /* A is already known to be 1 */
        b = 2.0 * (ray->dir.x * (ray->orig.x - curr_obj.args[0]) +
                   ray->dir.y * (ray->orig.y - curr_obj.args[1]) +
                   ray->dir.z * (ray->orig.z - curr_obj.args[2]));
        c = pow (ray->orig.x - curr_obj.args[0], 2.0) + pow (ray->orig.y - curr_obj.args[1], 2.0) +
            pow (ray->orig.z - curr_obj.args[2], 2.0) - pow (curr_obj.args[3], 2.0);


        /* calculate discriminant, determine if need to go on */
        discriminant = pow (b, 2.0) - 4.0 * c;


        if (discriminant > 0.0f) { /* 2 solutions */
            t_add = (-b + sqrt (discriminant)) / 2.0;
            t_sub = (-b - sqrt (discriminant)) / 2.0;

            point_at_t (&point_add, ray, t_add);
            point_at_t (&point_sub, ray, t_sub);

            /* disqualify if nan or not in front of view */
            if (t_add != t_add || t_add <= 0.0f) t_add = FLT_MAX;
            if (t_sub != t_sub || t_sub <= 0.0f) t_sub = FLT_MAX;

            /* cut things short if just trying to figure out shadow flag */
            if (trace_type > 0.0f && t_add < trace_type)
                return (color_t) {0, 0, 0};
            if (trace_type > 0.0f && t_sub < trace_type) /* in shadow */
                return (color_t) {0, 0, 0};
            else if (trace_type > 0.0f) /* not in shadow */
                continue;

            /* decide which is closest 
             * note: in a situation where previous closest_distance is the same as the closer of
             * these two new ones, the original closest_distance will remain */
            if (t_add <= t_sub && t_add < closest_distance) {
                closest_distance = t_add;
                surface_point = point_add;
            }
            else if (t_sub < t_add && t_sub < closest_distance) {
                closest_distance = t_sub;
                surface_point = point_sub;
            }
            else continue; /* skips assigning result_color */ 

            result_color = shade_ray (scene, &surface_point, i, -1, NULL);
        }
        else if (discriminant == 0.0f) { /* 1 solution */
            t_add = -b / 2.0;

            point_at_t (&point_add, ray, t_add);

            /* disqualify if nan or not in front of view */
            if (t_add != t_add || t_add <= 0.0f) continue;

            /* for shadow flag */
            if (trace_type > 0.0f && t_add < trace_type) /* in shadow */
                return (color_t) {0, 0, 0};
            else if (trace_type > 0.0f) /* not in shadow */
                continue;

            /* if this point is the new least distance along this ray, then replace it
             * and make result color the color of this object, otherwise move on */
            if (t_add < closest_distance) {
                result_color = shade_ray (scene, &point_add, i, -1, NULL);
                closest_distance = t_add;
            }
        }
    }

    /* check for collision with each triangle */
    for(i = 0; i < scene->tri_count; i++) {
        /* skip tri if coming from a shade ray call on itself */
        if (trace_type > 0.0f && src_tri == i) continue;

        curr_tri = &(scene->tris[i]);

        /* check if the ray intersects the plane */
        denominator = curr_tri->n.x * ray->dir.x +
                      curr_tri->n.y * ray->dir.y +
                      curr_tri->n.z * ray->dir.z;

        if (denominator == 0) continue; /* if the denominator is 0, no finite valued t */

        numerator = -(curr_tri->n.x * ray->orig.x +
                      curr_tri->n.y * ray->orig.y +
                      curr_tri->n.z * ray->orig.z +
                      curr_tri->d);

        t_add = numerator / denominator;

        point_at_t (&point_add, ray, t_add); /* point_add is point of intersection of ray/plane */

        /* disqualify if nan or not in front of view */
        if (t_add != t_add || t_add <= 0.0f) continue;


        /* if closest point thus far, check if point within triangle */
        if (t_add < closest_distance) {
            /* get dots of triangle vectors */
            d_00 = vec_dot (&(curr_tri->e0), &(curr_tri->e0));
            d_01 = vec_dot (&(curr_tri->e0), &(curr_tri->e1)); /* TODO: consider storing these in tri? */
            d_11 = vec_dot (&(curr_tri->e1), &(curr_tri->e1));

            /* if determinant of system = 0, no solution */
            determinant = d_00 * d_11 - d_01 * d_01;
            if (determinant == 0) continue;

            /* get vector from p0 to point */
            vec_from_to (&e_p, curr_tri->p[0], &point_add);

            /* get barycenrics beta and gamma with cramer's rule */
            d_0p = vec_dot (&(curr_tri->e0), &e_p);
            d_1p = vec_dot (&(curr_tri->e1), &e_p);

            barycentrics = (point_t) {
                0.0,
                (d_11 * d_0p - d_01 * d_1p) / determinant,
                (d_00 * d_1p - d_01 * d_0p) / determinant
            };
            barycentrics.x = 1 - barycentrics.y - barycentrics.z;
                       
            /* in triangle */
            if ((barycentrics.y > 0 && barycentrics.y < 1) && 
                (barycentrics.z > 0 && barycentrics.z < 1) && (barycentrics.x > 0)) {   
                /* do calc for shadow flag */
                if (trace_type > 0.0f && (t_add > 0.2f && t_add < trace_type)) 
                    return (color_t) {0, 0, 0};
                else if (trace_type > 0.0f)
                    continue;

                result_color = shade_ray (scene, &point_add, -1, i, &barycentrics); /*TODO: could lead to extraneous calls to shade, change this 
                                                                             instead store closest_point and closest_index vars */
                closest_distance = t_add;
            }
        }
    }

    /* if looking for shadow flag and no hits */
    if (trace_type > 0.0f)
        result_color = (color_t) {1, 1, 1};

    /* return result */
    return result_color;
}


/* shade ray, similar to spec */
color_t shade_ray (scene_t *scene, point_t *surface, int src_obj, int src_tri, point_t *bary_coords) {
    unsigned i, j, ray_count;
    float r, g, b,                   /* final color values */
          r_lit, g_lit, b_lit,       /* collects all light-dependent components */
          n_dot_l, n_dot_h,          /* intermediate calculations */
          light_surface_dist, f_att, /* for attenuation */
          alpha_dc,                  /* for depth cueing */
          light_delta, shadow_flag;  /* for soft shadows */

    point_t *eye,       /* view point in scene */
            obj_orig,   /* origin point of the object */
            light_orig, /* origin point of the light (used for point lights only */
            moved_light_orig;  /* for soft shadows */

    vector_t n, l, v, h; /* vectors used in calculations */

    ray_t shadow_ray;
    color_t new_shadow_flag; /* used in shadow calcs */

    mtl_color_t *color; /* TODO CLEAN THIS UP */

    triangle_t *tri;

    light_t *lights; /* light sources in scene */

    eye = &(scene->view_orig);
    lights = scene->lights;

    float u_f, v_f;
    int u_i, v_i, index; /* for texture mapping */

    /* get origin, color, normal vector */
    if (src_obj >= 0 && src_obj < scene->object_count) {
        obj_orig = (point_t) {
            scene->objects[src_obj].args[0],
            scene->objects[src_obj].args[1],
            scene->objects[src_obj].args[2]
        };

        /* mtl color */
        color = &(scene->objects[src_obj].color);/* TODO TODO: MAKE COLOR OF OBJ AND LIGHT AND DC A POINTER INSTEAD */
        
        /* surface normal */
        vec_from_to (&n, &obj_orig, surface);
        vec_normalize (&n);
    
        if (scene->objects[src_obj].texture != NULL) { /* reassign od if has a texture */
            /* get v (phi) and u (theta) */
            v_f = acos (n.z);
            u_f = atan2 (n.y, n.x);

            /* normalize v between 0 and 1 */
            v_f /= M_PI;

            /* normalize u between 0 and 1 correctly */
            if (u_f > 0) u_f /= 2 * M_PI;
            else if (u_f < 0) u_f = (u_f + 2 * M_PI) / ( 2 * M_PI);

            /* get color at point */
            u_i = (int) (u_f * scene->objects[src_obj].texture->w);
            v_i = (int) (v_f * scene->objects[src_obj].texture->h);

            index = (v_i * scene->objects[src_obj].texture->w + (u_i % scene->objects[src_obj].texture->w));

            color->od.r = scene->objects[src_obj].texture->px[index].r; 
            color->od.g = scene->objects[src_obj].texture->px[index].g; 
            color->od.b = scene->objects[src_obj].texture->px[index].b; 
        }
    }
    else if (src_tri >= 0 && src_tri < scene->tri_count) {
        tri = &(scene->tris[src_tri]);

        /* mtl color */
        color = tri->color;

        /* if tri has texture, reassign Od */
        if (tri->texture != NULL) {
            /* get u and v */
            u_f = bary_coords->x * tri->coords[0]->u +
                bary_coords->y * tri->coords[1]->u +
                bary_coords->z * tri->coords[2]->u;
            v_f = bary_coords->x * tri->coords[0]->v +
                bary_coords->y * tri->coords[1]->v +
                bary_coords->z * tri->coords[2]->v;

            /* get index into texture */
            u_i = (int) (u_f * tri->texture->w);
            v_i = (int) (v_f * tri->texture->h);

            index = (v_i * tri->texture->w + (u_i % tri->texture->w));

            color->od.r = tri->texture->px[index].r; 
            color->od.g = tri->texture->px[index].g; 
            color->od.b = tri->texture->px[index].b; 
        }

        /* surface normal */
        if (tri->norms[0] == NULL) /* no vert norms */
            n = (vector_t) { tri->n.x, tri->n.y, tri->n.z };
        else { /* with vert norms */
            n = (vector_t) {
                bary_coords->x * tri->norms[0]->x + bary_coords->y * tri->norms[1]->x + bary_coords->z * tri->norms[2]->x,
                bary_coords->x * tri->norms[0]->y + bary_coords->y * tri->norms[1]->y + bary_coords->z * tri->norms[2]->y,
                bary_coords->x * tri->norms[0]->z + bary_coords->y * tri->norms[1]->z + bary_coords->z * tri->norms[2]->z
            };
        }
        vec_normalize (&n);
    }
    else {
        fprintf (stderr, "shade_ray () was passed an incorrect or out-of-range source index, shade fail\n");
        return (color_t) {1, 0, 0};
    }

    /* ambient term */
    r = color->ka * color->od.r;
    g = color->ka * color->od.g;
    b = color->ka * color->od.b;


    /* vector from surface point to viewer */
    vec_from_to (&v, surface, eye);
    vec_normalize (&v);

    for (i = 0; i < scene->light_count; i++) {
        /* from surface towards light */
        if (lights[i].type == 0) { /* directional */
            l = (vector_t) {-lights[i].x, -lights[i].y, -lights[i].z};
            light_surface_dist = FLT_MAX; /* ALMOST infinitely far away */
        }
        else if (lights[i].type == 1 || lights[i].type == 2) { /* point */
            light_orig = (point_t) {lights[i].x, lights[i].y, lights[i].z};
            vec_from_to (&l, surface, &light_orig);
            light_surface_dist = vec_length (&l);
        }
        vec_normalize (&l);

        /* halfway between v and l */
        h = (vector_t) {l.x + v.x, l.y + v.y, l.z + v.z};
        vec_normalize (&h);

        /* diffuse term */
        n_dot_l = color->kd * fmax (0, vec_dot (&n, &l));
        r_lit = n_dot_l * color->od.r;
        g_lit = n_dot_l * color->od.g;
        b_lit = n_dot_l * color->od.b;

        /* specular term */
        n_dot_h = color->ks * pow (fmax (0.0, vec_dot (&n, &h)), color->n);
        r_lit += n_dot_h * color->os.r;
        g_lit += n_dot_h * color->os.g;
        b_lit += n_dot_h * color->os.b;

        /* factor in light hue/intensity */
        r_lit *= lights[i].color.r;
        g_lit *= lights[i].color.g;
        b_lit *= lights[i].color.b;

        /* attenuated lights */
        if (lights[i].type == 2) {
            f_att /= fmax (0.000001, (lights[i].c1 + lights[i].c2 * light_surface_dist + 
                         lights[i].c3 * pow (light_surface_dist, 2.0)));

            r_lit *= f_att;
            g_lit *= f_att;
            b_lit *= f_att;
        }

        /* factor in shadow */
        shadow_ray.orig = (point_t) {surface->x, surface->y, surface->z};
        shadow_ray.dir = (vector_t) {l.x, l.y, l.z};


        if (lights[i].type > 0 && scene->soft_shading == 1) { /* if soft shade on and point light, get many values */
            light_delta = scene->soft_shade_light_delta;
            ray_count = scene->soft_shade_ray_count;

            shadow_flag = 0.0;

            for (j = 0; j < ray_count; j++) {
                moved_light_orig.x = light_orig.x + light_delta * ((float) rand () / (float) (RAND_MAX / 2.0) - 1); 
                moved_light_orig.y = light_orig.y + light_delta * ((float) rand () / (float) (RAND_MAX / 2.0) - 1);
                moved_light_orig.z = light_orig.z + light_delta * ((float) rand () / (float) (RAND_MAX / 2.0) - 1);

                vec_from_to (&(shadow_ray.dir), &(shadow_ray.orig), &moved_light_orig);

                light_surface_dist = vec_length (&(shadow_ray.dir));
                vec_normalize (&(shadow_ray.dir));

                shadow_flag += trace_ray (&shadow_ray, scene, light_surface_dist, src_obj, src_tri).r;
            }

            shadow_flag /= (float) ray_count;
        }

        else { /* if soft shade off or directional, one simple ray will do */
            new_shadow_flag = trace_ray (&shadow_ray, scene, light_surface_dist, src_obj, src_tri);
            shadow_flag = new_shadow_flag.r;
        }
        
        r_lit *= shadow_flag;
        g_lit *= shadow_flag;
        b_lit *= shadow_flag;

        /* add into main terms */
        r += r_lit;
        g += g_lit;
        b += b_lit;
    }

    /* depth cue */
    if (scene->has_depth_cue == 1) {
        alpha_dc = depth_cue_alpha (&(scene->depth_cue), point_distance (eye, surface));

        r = alpha_dc * r + (1.0 - alpha_dc) * scene->depth_cue.color.r;
        g = alpha_dc * g + (1.0 - alpha_dc) * scene->depth_cue.color.g;
        b = alpha_dc * b + (1.0 - alpha_dc) * scene->depth_cue.color.b;
    }

    /* check for overflow */
    r = fmin (1.0, r);
    g = fmin (1.0, g);
    b = fmin (1.0, b);

    return (color_t) {r, g, b};
}
