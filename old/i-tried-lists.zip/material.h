/* 
 * chang
 *
 * Home of the "object," "object_list," "color," "mtl_color," and "mtl_color_list" typedefs.
 * Formerly the contents of object.h and color.h, this was redundant.
 */

#ifndef MATERIAL_H
#define MATERIAL_H

/*================================== COLORS =====================================*/

/* 
 * color_t:
 *   a typedef for colors, will be stored normalized between 0.0 and 1.0.
 */

typedef struct {
    float r, g, b;
} color_t;

/* converts from normalized storage to three int pointers of value between 0 and 255 */
void color_to_ints (color_t *color, int *r, int *g, int *b);

/* takes color_t array and creates {name}.ppm 
 * returns 1 if success, 0 if fail */
int write_colors_to_ppm (char *name, color_t *pixels, unsigned w, unsigned h);



/*
 * mtl_color_t:
 *   a typedef that defines an object's color (phong-ready)
 */

typedef struct mtl_color mtl_color_t;
struct mtl_color {
    color_t od,        /* diffuse color */
            os;        /* specular color */

    float ka,          /* ambient constant */
          kd,          /* diffuse constant */
          ks,          /* specular constant */
          n;           /* specular highlight falloff */

    mtl_color_t *next; /* next color in list */
};



/*
 * mtl_color_list_t:
 *   a typedef that stores mtl_colors as a singly-linked list.
 */

typedef struct {
    unsigned size;          /* number of mtl_colors in list */

    mtl_color_t *head; /* first element of list */
} mtl_color_list_t;

/* initializes dest with size 0 and a NULL head */
void mtl_color_list_init (mtl_color_list_t *dest);

/* adds given color to dest, 1 if success, 0 if fail */
int mtl_color_list_prepend (mtl_color_list_t *dest, mtl_color_t *new_color);



/*================================== OBJECTS ====================================*/

/* 
 * object_t:
 *   a typedef that allows all the necessary elements of an in-scene
 *   "object" to reside in one structure.
 *
 *   GUIDE TO TYPES: (all args are of float type)
 *     0 -- SPHERE
 *      arguments = { x, y, z, radius }
 *
 *     1 -- CYLINDER
 *      arguments = { x, y, z, dx, dy, dz, radius, length }
 *
 *   MORE TO COME
 */

typedef struct object object_t;
struct object {
    unsigned type,     /* type of object, e.g. 0 = sphere, 1 = cylinder */
             argcount; /* count of arguments (object type specific) */

    float *args;       /* argument array */

    mtl_color_t color;     /* color */

    object_t *next;    /* next object in list, NULL by default */
};

/* initializes an object_t of type t with color input_color and
 * parameters from input_args; stores to dest; 1 = success, 0 = fail */
int object_init (object_t *dest, unsigned t, mtl_color_t *input_color, char *input_args);



/* 
 * object_list_t:
 *   a typedef that forms a singly linked list of objects.
 */

typedef struct {
    unsigned size; /* number of objects in list */

    object_t *head; /* first object */
} object_list_t;

/* init object_list_t with size of 0 and NULL head */
void object_list_init (object_list_t *dest);

/* add object to object_list_t dest; 1 = success, 0 = fail */
int object_list_append (object_list_t *dest, unsigned t, mtl_color_t *input_color, char *input_args);

/* destroy all objects' args within object list */
void object_list_destroy (object_list_t *list);


#endif /* MATERIAL_H */
